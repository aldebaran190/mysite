#### Installation

```
git clone git@gitlab.com:vysakh0/mysite.git
cd mysite
yarn 
```

### To run the app

- Install `expo` app from the play store 

```
yarn start
```

Test login:

```
srvysakh@gmail.com
blahblah
```
Visit the given url or scan the barcode in the `expo app`

### To publish

```
exp publish
```

### To build the apk

```
exp build:android
```

### CONTRIBUTING

Before you start working on your feature.
Please take a look at [CONTRIBUTING.md](https://gist.github.com/vysakh0/4955c97a5e2b943b21fc) and follow them.

Begin your code :boom: Bonne Chance :metal:
