import React from 'react';
import { Font, AppLoading } from 'expo';
import { createStore, applyMiddleware, compose } from 'redux';
import createSagaMiddleware from 'redux-saga'
import appReducers from './src/reducers';
import mySaga from './src/sagas'
import styles from './src/styles';
import { setCurrentUser } from './src/reducers/application'
import {
  StyleSheet,
  Text,
  View,
  Alert
} from 'react-native'
import { connect } from 'react-redux'
import { AsyncStorage } from 'react-native';
import { addNavigationHelpers } from 'react-navigation';
import AppNavigator from './src/AppNavigator'
import { Notifications } from 'expo'
import { ApolloProvider } from 'react-apollo';
import apolloClient from './src/apolloClient'

// const localNotification = {
//   title: "Attendance Reminder",
//   body: "You have not checked in today",
//   ios: {
//     sound: true
//   },
//   android: {
//     sound: true,
//   }
// }
// const schedulingOptions = {
//   time: new Date("Wed Jul 12 2017 09:15:00 GMT+0530 (IST)").getTime(),
//   repeat: 'day'
// }
// Notifications.scheduleLocalNotificationAsync(localNotification, schedulingOptions);


// const listener = (event) => {
//   Alert.alert(
//     'Wooohoooo',
//     `${event.origin} ---> ${event.remote}`
//     [
//       {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
//     ]
//   )
//   console.log("wooooohooooo -> ", event)
// }

// Notifications.addListener(listener)

const sagaMiddleware = createSagaMiddleware()

const store = createStore(
  appReducers,
  compose(
    applyMiddleware(sagaMiddleware, apolloClient.middleware()),
  )
)
sagaMiddleware.run(mySaga)

export default class App extends React.Component {
  state = {
    loaded: false,
    userId: null
  }

  componentDidMount = async () => {
    try {
      const value = await AsyncStorage.getItem('userId');
      if (value !== null){
        this.setState({userId: value});
      }
    } catch (error) {
      console.log('Error in retrieving user Id from storage')
    } finally {
      this.setState({loaded: true});
    }
  }

  render() {
    const {loaded, userId} = this.state
    if(!loaded) {
      return(<AppLoading />)
    }
    return (
      <View style={styles.container}>
        <ApolloProvider client={apolloClient} store={store}>
          <AppNavigator userId={userId} />
        </ApolloProvider>
      </View>
    );
  }
}
