export const SET_GPS='SET_GPS'
export const FIND_LOCATION = 'FIND_LOCATION'
export const SET_LOCATION = 'SET_LOCATION'

export const setGpsEnabled = (val) => ({type: SET_GPS, val})
export const findLocation = (site, user) => ({type: FIND_LOCATION, site, user}) // user -> for passsing to setLocation
export const setLocation = (lat, lng, diff, user) => ({type: SET_LOCATION, lat, lng, diff, user}) // user -> for updating firebase

export default (state = {}, action) => {
  switch(action.type) {
  case SET_GPS:
    return {...state, gpsEnabled: action.val}
  case SET_LOCATION:
    return {...state, lat: action.lat, lng: action.lng, diff: action.diff}
  default:
    return state
  }
}
