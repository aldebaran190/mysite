import { combineReducers } from 'redux';
import application from './application';
import location from './location';
import apolloClient from '../apolloClient'

export default combineReducers({
  application,
  location,
  apollo: apolloClient.reducer(),
})
