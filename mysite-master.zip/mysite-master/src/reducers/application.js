export const LOGIN = 'LOGIN'
export const LOGOUT = 'LOGOUT'
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS'
export const LOGIN_FAILED = 'LOGIN_FAILED'
export const TRACK_SITE = 'TRACK_SITE'
export const NEW_MESSAGE = 'NEW_MESSAGE'
export const SET_MESSAGES = 'SET_MESSAGES'
export const NEW_RECORD = 'NEW_RECORD'
export const LOADING = 'LOADING'
export const USER_STATUS = 'USER_STATUS'
export const NOTIFICATION = 'NOTIFICATION'
export const USER_MANAGER = 'USER_MANAGER'
export const USER_UPDATE = 'USER_UPDATE'
export const SET_RESOURCE = 'SET_RESOURCE'

export const login = (email, password) =>
  ({type: LOGIN, email, password})
export const logout = () => ({type: LOGOUT})

export const loginSuccess = (data) => ({type: LOGIN_SUCCESS, data})
export const loginFailed = (data) => ({type: LOGIN_FAILED, data})
export const trackSite = (user) => ({type: TRACK_SITE, user})
export const newMessage = (user, message) => ({type: NEW_MESSAGE, user, message})
export const setMessages = (messages) => ({type: SET_MESSAGES, messages})
export const newRecord = (user, message, amount, image) => ({type: NEW_RECORD, user, message, amount, image})
export const setLoading = (bool) => ({type: LOADING, bool})
export const userStatus = (user, status) => ({type: USER_STATUS, user, status})
export const setDeviceDetails = (user) => ({type: NOTIFICATION, user})
export const watchUserManager = (user) => ({type: USER_MANAGER, user})
export const updateUser = (user) => ({type: USER_UPDATE, user})
export const setUser = (user) => ({type: SET_RESOURCE, user})

const initialState = {status: 'check-out'}

export default (state = initialState, action) => {
  switch (action.type) {
  case LOGIN_SUCCESS:
    return {...state, user: action.data}
  case LOGIN_FAILED:
    return {...state, errors: action.data}
  case LOGOUT:
    return {...state, userId: null}
  case USER_UPDATE:
    return {...state, user: action.user}
  case SET_MESSAGES:
    return {...state, messages: action.messages}
  case LOADING:
    return {...state, loading: action.bool}
  case USER_STATUS:
    return {...state, status: action.status}
  case SET_RESOURCE:
    return {...state, userId: action.user}
  default:
    return state
  }
}
