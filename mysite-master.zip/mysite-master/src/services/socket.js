import { Socket } from 'phoenix-socket'

const URL = process.env.REACT_NATIVE_ENV  === 'dev' ? 'localhost:3000' : 'productionurl.oooo'
let socket = new Socket(`ws://${URL}/socket`)

socket.connect();

export default socket;
