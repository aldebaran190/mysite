import Promise from 'bluebird';
const dev = process.env.REACT_NATIVE_ENV
const URL =  dev ? `${dev.trim()}:4000` : '188.166.36.168'
export default (path, method, body = {}) => {
  const headers = {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  }
  let options = {
    method: method,
    headers
  }

  if(method !== 'GET') options.body = JSON.stringify(body)

  return new Promise((resolve, reject) => {
    fetch(
      `http://${URL}/api/${path}`,
      options
    )
    .then(response => {
      if (method === 'DELETE') {
        return response.ok ? resolve('ok') : reject(new Error("Couldn't delete"));
      }
      return response.json().then(json => {
        const errors = JSON.stringify(json.errors);
        return response.ok ? resolve(json) : reject(new Error(errors));
      });
    });
  });
}
