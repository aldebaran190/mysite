import * as firebase from 'firebase';
const config = {
	apiKey: "AIzaSyDU7ZrQBLOmN68Gswge8l4sc9r4l1Jt6cs",
	authDomain: "track-site-cdf96.firebaseapp.com",
	databaseURL: "https://track-site-cdf96.firebaseio.com",
	projectId: "track-site-cdf96",
	storageBucket: "track-site-cdf96.appspot.com",
	messagingSenderId: "960407227333"
};
firebase.initializeApp(config)

export default firebase
