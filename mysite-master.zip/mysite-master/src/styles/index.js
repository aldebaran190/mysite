import { StyleSheet } from 'react-native';
import Expo from 'expo';

export default StyleSheet.create({
  success: {
    backgroundColor: '#E1D7D8',
    padding: 30,
    flexDirection: 'column'
  },
  textLabel: {
    fontSize: 30,
    marginBottom: 10,
    color: '#0cb256'
  },
  container: {
    flex: 4,
    backgroundColor: '#fff',
    justifyContent: 'center',
    padding: 2,
  },
  header: {
    fontSize: 32
  },
  errorBox: {
    padding: 4
  },
  errorText: {
    color: '#f00'
  },
  form: {
    flex: 1,
  },
  input: {
    margin: 15,
    height: 40,
    fontSize: 16,
    padding: 4
  },
});
