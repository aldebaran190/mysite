import { ApolloClient, createNetworkInterface } from 'react-apollo';
import {SubscriptionClient, addGraphQLSubscriptions} from 'subscriptions-transport-ws'

const wsClient = new SubscriptionClient(`wss://subscriptions.graph.cool/v1/cj620yry0chje0150r2jybjw2`, {
  reconnect: true,
  connectionParams: {
    // Pass any arguments you want for initialization
  }
})

const networkInterface = createNetworkInterface({
  uri: 'https://api.graph.cool/simple/v1/cj620yry0chje0150r2jybjw2',
})

const networkInterfaceWithSubscriptions = addGraphQLSubscriptions(
  networkInterface,
  wsClient
)
const client = new ApolloClient({
  networkInterface: networkInterfaceWithSubscriptions
});

export default client
