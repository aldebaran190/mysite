import React from 'react';
import { MapView } from 'expo';

export default class Gmaps extends React.Component {
  fitMap = (coordinates) => {
    if(coordinates.length > 0)
      this.mapRef.fitToCoordinates(coordinates, { edgePadding: { top: 5, right: 5, bottom: 5, left: 5 }, animated: false })
  }

  render() {
    const {markers, initLat, initLng} = this.props
    const coordinates = markers.map(marker => marker.latlng)

    return(
      <MapView
          ref={(ref) => {this.mapRef = ref}}
          initialRegion={{
            latitude: initLat,
            longitude: initLng,
            latitudeDelta: 0.0422,
            longitudeDelta: 0.0221
          }}
          style={{flex: 1}}
      >
        {markers.map(marker => (
           <MapView.Marker
                 key={marker.id}
                 coordinate={marker.latlng}
                 title={marker.title}
                 image={marker.image}
           />
         ))}
      </MapView>
    )
  }
}
