import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const styles = StyleSheet.create({
  content:{
    flex:1,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center'
  },
  messageBox:{
    backgroundColor:'#ef553a',
    width:300,
    paddingTop:10,
    paddingBottom:20,
    paddingLeft:20,
    paddingRight:20,
    borderRadius:10
  },
  messageBoxTitleText:{
    fontWeight:'bold',
    color:'#fff',
    textAlign:'center',
    fontSize:20,
    marginBottom:10
  },
  messageBoxBodyText:{
    color:'#fff',
    fontSize:16
  }
})

export default () => (
  <View style={styles.content}>
    <View style={styles.messageBox}>
      <View>
        <Text style={styles.messageBoxTitleText}>LOCATION DISABLED</Text>
      </View>
      <View>
        <Text style={styles.messageBoxBodyText}>Please close your app, then enable your location services and re-open the app.</Text>
      </View>
    </View>
  </View>
)
