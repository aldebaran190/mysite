import React from 'react';
import { connect } from 'react-redux'
import { TabNavigator, StackNavigator } from 'react-navigation'
import LoginScreen from '../src/screens/Login.js';
import HomeScreen from '../src/screens/Home';
import MessageScreen from '../src/screens/messages/Index';
import NewMessageScreen from '../src/screens/messages/New';
import RecordScreen from '../src/screens/records/Index';
import NewRecordScreen from '../src/screens/records/New';
import EditRecordScreen from '../src/screens/records/Edit';
import SettingScreen from '../src/screens/Settings';
import ForgotPasswordScreen from '../src/screens/ForgotPassword';
import ReportsScreen from '../src/screens/Reports';
import Spinner from 'react-native-loading-spinner-overlay';
import { gql, graphql } from 'react-apollo';

const messages = StackNavigator({
  AllMessages: {
    screen: MessageScreen
  },
  NewMessage: {
    screen: NewMessageScreen
  }
})

const records = StackNavigator({
  AllRecords: {
    screen: RecordScreen
  },
  NewRecord: {
    screen: NewRecordScreen
  },
  EditRecord: {
    screen: EditRecordScreen
  }
})

const settings = StackNavigator({
  Settings: {
    screen: SettingScreen
  },
  Reports: {
    screen: ReportsScreen
  },
})

const AfterLogin = TabNavigator({
  Home: {
    screen: HomeScreen
  },
  Messages: {
    screen: messages
  },
  Records: {
    screen: records
  },
  Settings: {
    screen: settings
  }
}, {
  navigationOptions: {
    header: null
  },
  tabBarOptions: {
    showIcon: true,
    showLabel: false,
    labelStyle: {
      fontSize: 12,
    },
    indicatorStyle: {
      backgroundColor: "lime",
      height: 3
    }
  }
});

const BeforeLogin = StackNavigator({
  Login: {
    screen: LoginScreen
  },
  ForgotPassword: {
    screen: ForgotPasswordScreen
  }
});

class AppNavigator extends React.Component {
  render() {
    const {userId} = this.props
    if(userId) {
      return <NewContainer userId={userId} key={Date.now()} />
    } else {
      return <BeforeLogin />
    }
  }
}

const AfterLoginContainer = (props) => {
  const data = props.data
  console.log("PROPS -> ", props)
  if(data.loading || data.error) {return <Spinner visible />}
  return <AfterLogin screenProps={props.data} />
}

const FetchUserQuery = gql`
    query UserFetch($id: ID!) {
        user: User(id: $id) {
            name
            status
            id
            manager {
              id
              name
            }
            userOnSites {
                id
                site {
                    id
                    name
                    lat
                    lng
                }
            }
        }
      }
`

const NewContainer = graphql(FetchUserQuery, {
  options: (props) => ({
    variables: {
      id: props.userId,
    }
  })
})(AfterLoginContainer)

export default connect(
  (state, props) => ({
    userId: props.userId || state.application.userId,
  }),
)(AppNavigator);
