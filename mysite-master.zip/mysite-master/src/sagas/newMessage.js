import { call, put, takeLatest } from 'redux-saga/effects'
import {
  NEW_MESSAGE,
  setMessages
} from '../reducers/application'
import firebase from '../firebase';

function createMessage(action) {
  const { user, message } = action
  const newMessage = {
    userId: user.uid,
    userName: user.name,
    createdAt: new Date().getTime(),
    message
  }
  return firebase.database().ref(user.company + '/messages').push(newMessage)
}

function* createNewMessage(action) {
  try {
    yield call(createMessage, action)
    /*     yield put(setMessages()*/
  } catch (e) {
    console.log("Message creation failed")
  }
}

export function* watchNewMessage() {
  yield takeLatest(NEW_MESSAGE, createNewMessage)
}
