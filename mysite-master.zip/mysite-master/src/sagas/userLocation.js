import { call, put, takeLatest } from 'redux-saga/effects'
import {
  SET_LOCATION
} from '../reducers/location'
import apolloClient from '../apolloClient'
import {gql} from 'react-apollo'

function setCurrentLocation({user, lat, lng, diff}) {
  const UpdateUserQuery = gql`
    mutation UpdateUser($id: ID!, $lat: String!, $lng: String!) {
      updateUser(id: $id, lat: $lat, lng: $lng) {
        id
      }
    }

  `
  return apolloClient.mutate({mutation: UpdateUserQuery, variables: {id: user.id, lat: String(lat), lng: String(lng)}})
}

function* updateUserLocation(action) {
  console.log("Updating user location\n", action)
  try {
    const response = yield call(setCurrentLocation, action)
    console.log(response)
  } catch (e) {
    console.log("------>", e.message);
  }
}

export function* watchUserLocation() {
  yield takeLatest(SET_LOCATION, updateUserLocation)
}
