import { watchSignIn } from './signin'
import { watchLocation } from './location'
import { siteData } from './site'
import { watchNewMessage } from './newMessage'
import { watchNewRecord } from './record'
import { watchUserLocation } from './userLocation'
import { watchUserStatus } from './userStatus'
import { notificationPoop } from './notification'
import { watchUserManagerChange } from './userManager'

export default function* rootSaga() {
  yield [
    notificationPoop(),
    watchSignIn(),
    watchLocation(),
    siteData(),
    watchNewMessage(),
    watchNewRecord(),
    watchUserLocation(),
    watchUserStatus(),
    watchUserManagerChange(),
  ]
}
