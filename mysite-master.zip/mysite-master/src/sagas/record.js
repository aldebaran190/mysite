import { call, put, takeLatest } from 'redux-saga/effects'
import {
  NEW_RECORD
} from '../reducers/application'
import firebase from '../firebase';
import { RNS3 } from 'react-native-aws3';

function createRecord({user, message, amount, imageUrl}) {
  const newRecord = {
    userId: user.uid,
    userName: user.name,
    createdAt: new Date().getTime(),
    message,
    amount,
    url: imageUrl
  }
  return firebase.database().ref(user.company + '/records').push(newRecord)
}

function uploadImage({image}) {
  const file = {
    uri: image,
    name: `${new Date().getTime()}.jpg`,
    type: 'image/jpg'
  }
  const options = {
    keyPrefix: "ts/",
    bucket: "celeb-c4u",
    region: "eu-west-1",
    accessKey: "AKIAI2NHLR7A5W2R3OLA",
    secretKey: "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",
    successActionStatus: 201
  }
  return RNS3.put(file, options)
}

function* createNewRecord(action) {
  try {
    if(action.image) {
      const response = yield call(uploadImage, action)
      action.imageUrl = response.body.postResponse.location
    }
    yield call(createRecord, action)
  } catch (e) {
    console.log("Record creation failed")
  }
}

export function* watchNewRecord() {
  yield takeLatest(NEW_RECORD, createNewRecord)
}
