import { call, put, takeLatest } from 'redux-saga/effects'
import {
  TRACK_SITE,
} from '../reducers/application'
import { setSiteLocation } from '../reducers/location'
import firebase from '../firebase';

function getSiteId({user}) {
  const { company, uid } = user
  return firebase.database().ref(company + '/users/' + uid + '/site/id').once('value')
}

function getSite({user}, id) {
  const { company } = user
  const url = `${company}/sites/${id}`
  return firebase.database().ref(url).once('value')
}

function* fetchSite(action) {
  try {
    const siteId = yield call(getSiteId, action)
    if(siteId.val()) {
      const site = yield call(getSite, action, siteId.val())
      yield put(setSiteLocation({...site.val(), key: site.key}))  
    } 
  } catch (e) {
    console.log(e.message);
    //yield put(trackFailed(e.message))
  }
}

export function* siteData() {
  yield takeLatest(TRACK_SITE, fetchSite)
}
