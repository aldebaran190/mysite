import { call, put, takeLatest } from 'redux-saga/effects'
import {
  NOTIFICATION,
} from '../reducers/application'
import firebase from '../firebase';
import { Permissions, Notifications } from 'expo';

function updateDeviceId({user}, token) {
  console.log("token ---> ", token)
  const { company, uid } = user
  return firebase.database().ref(`${company}/users/${uid}`).update({deviceId: token})
}

function* deviceDetails(action) {
  try {
    const { getAsync, REMOTE_NOTIFICATIONS, askAsync } = Permissions;
    const { existingStatus } = yield call(getAsync, REMOTE_NOTIFICATIONS)
    let finalStatus = existingStatus;
    if (existingStatus !== 'granted') {
      const { status } = yield call(getAsync, REMOTE_NOTIFICATIONS)
      finalStatus = status;
    }

    if (finalStatus === 'granted') {
      const token = yield call(Notifications.getExponentPushTokenAsync)
      yield call(updateDeviceId, action, token)
      console.log("token success---> ")
    }
  } catch (e) {
    console.log(e.message);
  }
}

export function* notificationPoop() {
  yield takeLatest(NOTIFICATION, deviceDetails)
}
