import {
  call,
  put,
  take,
  apply,
  cancelled,
  takeLatest,
  fork
} from 'redux-saga/effects'
import {
  setLocation,
  setGpsEnabled,
  FIND_LOCATION
} from '../reducers/location'
import { Location, Permissions  } from 'expo'
import { eventChannel, delay } from 'redux-saga'
import {Alert} from 'react-native'
const deg2Rad = (deg) => deg * Math.PI / 180

const pythagorasEquirectangular = (la1, lo1, la2, lo2) => {
  const lat1 = deg2Rad(la1);
  const lat2 = deg2Rad(la2);
  const lon1 = deg2Rad(lo1);
  const lon2 = deg2Rad(lo2);
  const R = 6371; // in km
  const x = (lon2 - lon1) * Math.cos((lat1 + lat2) / 2);
  const y = (lat2 - lat1);
  const d = Math.sqrt(x * x + y * y) * R;
  return d;
}

async function locationSubscribe({site, user}) {
  return eventChannel(emit => {
    let subscription;
    subscription = Location.watchPositionAsync({enableHighAccuracy: true, timeInterval: 2000, distanceInterval: 2}, (position) => {
      const long1 = position.coords.longitude
      const lat1 = position.coords.latitude
      if(site) {
        const {lat, lng} = site;
        const d = pythagorasEquirectangular(parseFloat(lat1), parseFloat(long1), parseFloat(lat), parseFloat(lng))
        return emit(setLocation(lat1, long1, d, user))
      } else {
        return emit(setLocation(lat1, long1, null, user))
      }
    });

    const unsubscribe = () => {
      //subscription.remove()
    }

    return unsubscribe;
  });
}

function* location(action) {
  const { askAsync, LOCATION } = Permissions;
  const { status } = yield call(askAsync, LOCATION);
  if (status === 'granted') {
    const {locationServicesEnabled} = yield call(Location.getProviderStatusAsync)
    if(!locationServicesEnabled) {
      yield put(setGpsEnabled(false))
      Alert.alert(
        'WARNING',
        'Please turn on your Location Services(GPS)',
        [
          {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
        ]
      )
      return null;
    }
    const loc = yield call(locationSubscribe, action)
    try {
      while (true) {
        const nextAction = yield take(loc)
        yield put(setGpsEnabled(true))
        yield put(nextAction)
      }
    } finally {
      if(yield cancelled()) {
        loc.close()
      }
    }
  } else {
    throw new Error('Location permission not granted');
  }
}

export function* watchLocation() {
  yield fork(takeLatest, FIND_LOCATION, location)
}
