import { call, put, takeLatest } from 'redux-saga/effects'
import {
  loginSuccess,
  LOGIN,
  loginFailed,
  setLoading
} from '../reducers/application'
import firebase from '../firebase';

function login(email, password) {
  return firebase.auth().signInWithEmailAndPassword(email, password)
}

function* signIn(action) {
  try {
    yield put(setLoading(true))
    const userData = yield call(login, `91${action.email}@ciyat.com`, action.password)
    const displayName = JSON.parse(userData.displayName)
    const user = {uid: userData.uid, email: userData.email, company: displayName.company, name: displayName.name}
    yield put(loginSuccess(user))
    yield put(setLoading(false))
  } catch (e) {
    yield put(setLoading(false))
    yield put(loginFailed(e.message))
  }
}

export function* watchSignIn() {
  yield takeLatest(LOGIN, signIn)
}
