import { call, put, takeLatest } from 'redux-saga/effects'
import {
  USER_STATUS,
} from '../reducers/application'
import firebase from '../firebase';

function setCurrentStatus(user, status) {
  const { company, uid } = user
  const ref = `${company}/users/${uid}`
  return firebase.database().ref(ref).update({status})
}

function* updateUserStatus(action) {
  try {
    const {user, status} = action
    yield call(setCurrentStatus, user, status)
  } catch (e) {
    console.log("------>", e.message);
  }
}

export function* watchUserStatus() {
  yield takeLatest(USER_STATUS, updateUserStatus)
}
