import { call, put, takeLatest } from 'redux-saga/effects'
import {
  USER_MANAGER,
  updateUser,
} from '../reducers/application'
import firebase from '../firebase';

function getManager({user}) {
  const { company, uid } = user
  return firebase.database().ref(company + '/users/' + uid + '/manager').once('value')
}

function* updateManager(action) {
  try {
    const snap = yield call(getManager, action)
    const manager = snap.val()
    if(manager) {
      yield put(updateUser({...action.user, manager}))
    } 
  } catch (e) {
    console.log(e.message);
    //yield put(trackFailed(e.message))
  }
}

export function* watchUserManagerChange() {
  yield takeLatest(USER_MANAGER, updateManager)
}
