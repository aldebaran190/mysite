import { take, put, call, apply } from 'redux-saga/effects'
import { eventChannel, delay } from 'redux-saga'
import socket from '../services/socket'

function createSocketChannel(channel) {
  return eventChannel(emit => {
    const newStoryHandler = (event) => {
      emit(newStoryReceived(event));
    }

    channel.on('new_story', newStoryHandler);

    const unsubscribe = () => {
      channel.off('new_story', newStoryHandler)
    }

    return unsubscribe;
  });
}
function* connectToChannel() {
  const channel = socket.channel('name', {token: ''})
  channel.join()

  const socketChannel = yield call(createSocketChannel, channel);

  while (true) {
    const action = yield take(socketChannel)
    yield put(action)
  }
}
export function* getWatcher() {
  yield fork(takeLatest, 'CONNECT_CHANNEL', connectToChannel);
}
