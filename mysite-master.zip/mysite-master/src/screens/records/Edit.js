import React from 'react';
import { TextInput, Text, View, Button, Image, TouchableHighlight, TouchableOpacity, Alert } from 'react-native';
import { ImagePicker } from 'expo';
import styles from '../../styles';
import { Ionicons } from '@expo/vector-icons';
import { RNS3 } from 'react-native-aws3';
import firebase from '../../firebase';
import { connect } from 'react-redux'

class Edit extends React.Component {
  static navigationOptions = {
    title: 'Edit Record',
    tabBarIcon: () => (<Ionicons name="md-create" size={30} color="white" />),
  }

  state = {
    loading: false,
    errors: null
  }

  componentWillMount() {
    const {url, message, amount, key} = this.props.navigation.state.params.record
    this.setState({
      imageUrl: url,
      message,
      amount,
      key
    })
  }

  onSubmit = async () => {
    const { image, message, amount, key } = this.state;
    this.setState({loading: true})
    try {
      let url = null
      if(image) {
        const uploadImageResponse = await this.uploadImage(image)
        url = uploadImageResponse.body.postResponse.location
      }
      await this.createRecord(message, amount, url, key)
      this.props.navigation.navigate('AllRecords')
      Alert.alert(
        'SUCCESS',
        'Your expense has been edited successfully',
        [
          {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
        ]
      )
    } catch(e) {
      this.setState({loading: false, errors: e.message})
    }
  }

  showErrors(errors) {
    return(
      <View style={styles.errorBox}>
        <Text style={styles.errorText}>
          {errors}
        </Text>
      </View>
    )
  }

  createRecord = (message, amount, imageUrl, key) => {
    const user = this.props.user
    const newRecord = {
      message,
      amount,
      url: imageUrl
    }
    return firebase.database().ref(`${user.company}/records/${key}`).update(newRecord)
  }

  uploadImage = (image) => {
    const file = {
      uri: image,
      name: `${new Date().getTime()}.jpg`,
      type: 'image/jpg'
    }
    const options = {
      keyPrefix: "ts/",
      bucket: "celeb-c4u",
      region: "eu-west-1",
      accessKey: "AKIAI2NHLR7A5W2R3OLA",
      secretKey: "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",
      successActionStatus: 201
    }
    return RNS3.put(file, options)
  }

  render() {
    const { image, message, amount, loading, imageUrl } = this.state;
    const { user, newRecord } = this.props;

    return (
      <View style={styles.form}>
        <TextInput
            multiline={true}
            numberOfLines={4}
            style={styles.input}
            placeholder="Message"
            value={message}
            onChangeText={(e) => this.setState({message: e})}
        />
        <TextInput
            multiline={true}
            numberOfLines={4}
            keyboardType="numeric"
            style={styles.input}
            placeholder="Amount"
            value={amount}
            onChangeText={(e) => this.setState({amount: e})}
        />
        {
          !image && !imageUrl &&
          <TouchableOpacity style={{alignItems: 'center', backgroundColor: "seagreen", justifyContent: 'center', height: 35}} onPress={this._pickImage}>
            <Text style={{color: "white", fontSize: 14, fontWeight: 'bold'}}>ADD IMAGE</Text>
          </TouchableOpacity>
        }
        {
          (image || imageUrl) &&
          <View style={{flexDirection: 'row', flexWrap: 'wrap', flex: 8, maxHeight: 200}}>
            <Image source={{ uri: (image || imageUrl) }} style={{height: 200, flex: 5}} />
            <View style={{flex: 2, marginLeft: 20, marginTop: 20}} >
              <TouchableOpacity onPress={this._pickImage}>
                <Ionicons name="md-refresh-circle" size={50} color="seagreen" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.setState({image: null, imageUrl: null})}>
                <Ionicons name="md-remove-circle" size={50} color="crimson" />
              </TouchableOpacity>
            </View>
          </View>
        }
        <Text>{"\n"}</Text>
        {this.state.errors ? this.showErrors(this.state.errors) : null}
        <Button
            color="seagreen"
            onPress={this.onSubmit}
            disabled={loading}
            title={loading ? "Submitting" : "Submit"}
        />
      </View>
    );
  }

  _pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true
    });

    if (!result.cancelled) {
      this.setState({ image: result.uri });
    }
  };
}


export default connect(
  (state) => ({
    user: state.application.user,
  })
)(Edit);
