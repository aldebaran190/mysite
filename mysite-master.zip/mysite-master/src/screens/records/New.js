import React from 'react';
import { TextInput, Text, View, Button, Image, TouchableHighlight, TouchableOpacity, Alert } from 'react-native';
import { ImagePicker } from 'expo';
import styles from '../../styles';
import { connect } from 'react-redux'
import { Ionicons } from '@expo/vector-icons';
import { RNS3 } from 'react-native-aws3';
import { gql, graphql} from 'react-apollo';

class New extends React.Component {
  static navigationOptions = {
    title: 'New Expense',
    tabBarIcon: () => (<Ionicons name="md-create" size={30} color="white" />),
  }

  state = {
    image: null,
    message: '',
    amount: null,
    loading: false,
    errors: null
  }

  onSubmit = async () => {
    const { image, message, amount } = this.state;
    this.setState({loading: true})
    try {
      let url = null
      console.log("+============== IMAGE--> ", image)
      if(image) {
        const uploadImageResponse = await this.uploadImage(image)
        console.log("Image response ---> ", uploadImageResponse)
        url = uploadImageResponse.body.postResponse.location
      }
      console.log("URL ---> ", url)
      await this.createRecord(message, amount, url)
      this.setState({image: null, message: '', amount: null, loading: false})
      Alert.alert(
        'SUCCESS',
        'Your expense has been shared successfully',
        [
          {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
        ]
      )
    } catch(e) {
      this.setState({loading: false, errors: e.message})
    }
  }

  showErrors(errors) {
    return(
      <View style={styles.errorBox}>
        <Text style={styles.errorText}>
          {errors}
        </Text>
      </View>
    )
  }

  createRecord = (title, amount, imageUrl) => {
    const { screenProps, mutate } = this.props;
    const {id, manager} = screenProps.user;
    const time = new Date().toISOString()
    const newRecord = {
      userId: id,
      expenseDate: time,
      managerId: manager ? manager.id : null,
      amount: parseFloat(amount),
      title,
      attachment: imageUrl
    }
    return mutate({variables: newRecord})
  }

  uploadImage = (image) => {
    const file = {
      uri: image,
      name: `${new Date().getTime()}.jpg`,
      type: 'image/jpg'
    }
    const options = {
      keyPrefix: "ts/",
      bucket: "celeb-c4u",
      region: "eu-west-1",
      accessKey: "AKIAI2NHLR7A5W2R3OLA",
      secretKey: "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",
      successActionStatus: 201
    }
    return RNS3.put(file, options)
  }

  render() {
    const { image, message, amount, loading } = this.state;
    const { user, newRecord } = this.props;

    return (
      <View style={styles.form}>
        <TextInput
            multiline={true}
            numberOfLines={4}
            style={styles.input}
            placeholder="Message"
            value={message}
            onChangeText={(e) => this.setState({message: e})}
        />
        <TextInput
            multiline={true}
            numberOfLines={4}
            keyboardType="numeric"
            style={styles.input}
            placeholder="Amount"
            value={amount}
            onChangeText={(e) => this.setState({amount: e})}
        />
        {
          !image &&
          <TouchableOpacity style={{alignItems: 'center', backgroundColor: "seagreen", justifyContent: 'center', height: 35}} onPress={this._pickImage}>
            <Text style={{color: "white", fontSize: 14, fontWeight: 'bold'}}>ADD IMAGE</Text>
          </TouchableOpacity>
        }
        {
          image &&
          <View style={{flexDirection: 'row', flexWrap: 'wrap', flex: 8, maxHeight: 200}}>
            <Image source={{ uri: image }} style={{height: 200, flex: 5}} />
            <View style={{flex: 2, marginLeft: 20, marginTop: 20}} >
              <TouchableOpacity onPress={this._pickImage}>
                <Ionicons name="md-refresh-circle" size={50} color="seagreen" />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => this.setState({image: null})}>
                <Ionicons name="md-remove-circle" size={50} color="crimson" />
              </TouchableOpacity>
            </View>
          </View>
        }
        <Text>{"\n"}</Text>
        {this.state.errors ? this.showErrors(this.state.errors) : null}
        <Button
            color="seagreen"
            onPress={this.onSubmit}
            disabled={loading}
            title={loading ? "Submitting" : "Submit"}
        />
      </View>
    );
  }

  _pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      allowsEditing: true
    });

    if (!result.cancelled) {
      this.setState({ image: result.uri });
    }
  };
}

const MutationQuery = gql`
    mutation createExpense($expenseDate: DateTime!, $title: String!, $amount: Float!, $attachment: String, $userId: ID!, $managerId: ID!) {
      createExpense(title: $title, expenseDate: $expenseDate, attachment: $attachment, amount: $amount, userId: $userId, managerId: $managerId) {id}
    }
`
export default graphql(MutationQuery)(New)
