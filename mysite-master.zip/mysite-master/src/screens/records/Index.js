import React from 'react';
import { Text, ListView, View, TouchableHighlight, StyleSheet, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux'
import { gql, graphql } from 'react-apollo';
import { FontAwesome, Ionicons } from '@expo/vector-icons';
import moment from 'moment'

import Spinner from 'react-native-loading-spinner-overlay';

class ExpensesIndex extends React.Component {
  static navigationOptions = {
    header: false,
    tabBarIcon: () => (<FontAwesome name="rupee" size={30} color="white" />),
  }

  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {
      messages: [],
      ds
    }
  }

  renderRows(data) {
    return(
      <TouchableOpacity onPress={() => this.props.navigation.navigate('EditRecord', {record: data})} style={{flexDirection: 'column', borderBottomWidth: 2, borderColor:'#f7f7f7', padding: 10}}>
        <View style={{ alignItems:'center', flexDirection:'row' }}>
          <View style={{ flexDirection:'row', justifyContent:'space-between', width:280 }}>
            <Text style={{ marginLeft:15, fontWeight:'600' }}>{data.title}</Text>
            <Text style={{ color:'#333', fontSize:10 }}>{moment(data.expenseDate).fromNow()}</Text>
          </View>
        </View>
        <View>
          <Text style={{ marginLeft:15 }}><FontAwesome name="rupee" size={15} />{data.amount}</Text>
        </View>
      </TouchableOpacity>
    )
  }

  render() {
    const { allExpenses, loading } = this.props.data;

    if(loading) return(<Spinner visible={true} />)

    const dataSource = this.state.ds.cloneWithRows(allExpenses)
    return(
      <View style={{flex: 1}}>
        <TouchableOpacity onPress={() => this.props.navigation.navigate('NewRecord')} style={{alignSelf: 'flex-end', paddingTop: 10, paddingRight: 20}} >
          <Ionicons name="md-add-circle" size={50} color="seagreen" />
        </TouchableOpacity>
        <ListView
            dataSource={dataSource}
            renderRow={(data) => this.renderRows(data)}
            enableEmptySections={true}
        />
      </View>
    )
  }
}

const allExpensesQuery = gql`
  query allExpenses($id: ID!) {
     allExpenses(filter: {user: {id: $id}}) {
        id
        attachment
        title
        amount
        expenseDate
  }
}
`

export default graphql(allExpensesQuery, {
  options: (props) => ({
    variables: {id: props.screenProps.user.id}
  })
})(ExpensesIndex)
