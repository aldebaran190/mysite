import React from 'react';
import { TextInput, Text, View, Button, Alert } from 'react-native';
import styles from '../styles';
import firebase from '../firebase';
import Spinner from 'react-native-loading-spinner-overlay';

export default class ForgotPassword extends React.Component {
  static navigationOptions = {
    title: 'Password Reset',
  }

  state = {
    phone: '',
    loading: false,
  }

  setError = () => {
    this.setState({loading: false})
    Alert.alert(
      'ERROR',
      'Please check the number you have entered',
      [
        {text: 'OK', onPress: () => console.log("OK"), style: 'cancel'}
      ]
    )
  }

  resetPassword = () => {
    const phone = this.state.phone
    const nav = this.props.navigation
    this.setState({loading: true})
    const GRAPHQL_ENDPOINT = 'https://api.graph.cool/simple/v1/cj620yry0chje0150r2jybjw2'

    const options = {
      uri: GRAPHQL_ENDPOINT,
      headers: {
        'Content-Type': 'application/json',
      },
      method: 'POST',
      body: JSON.stringify({
        query: `
            mutation {
                resetPassword(phone: "${phone.trim()}") {
                    id
                }
            }
        `
      })
    }

    fetch(GRAPHQL_ENDPOINT, options)
      .then(resp => resp.json())
      .then(res => {
        this.setState({loading: false})
        console.log(res)
        if(res.errors) {
          this.setError();
          return null
        }
        Alert.alert(
          'SUCCESS',
          'Please check your phone for a temporary password. And login with it.',
          [
            {text: 'OK', onPress: () => nav.navigate('Login'), style: 'cancel'}
          ]
        )
      })
  }

  render() {
    return (
      <View style={styles.form}>
        <Spinner visible={this.state.loading} />
        <TextInput
            style={styles.input}
            placeholder="Phone"
            value={this.state.phone}
            onChangeText={(e) => this.setState({phone: e})}
        />
        <Button
            color="seagreen"
            onPress={this.resetPassword}
            title={"Submit"}
        />
      </View>
    );
  }
}
