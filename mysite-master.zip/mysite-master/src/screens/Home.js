import React from 'react';
import { Text, View, Button, Alert, TouchableHighlight, TouchableOpacity } from 'react-native';
import styles from '../styles';
import { connect } from 'react-redux'
import { trackSite, logout, userStatus, setDeviceDetails, watchUserManager } from '../reducers/application'
import { findLocation } from '../reducers/location'
import { Ionicons, Entypo } from '@expo/vector-icons';
import Spinner from 'react-native-loading-spinner-overlay';
import Gmaps from '../components/Gmaps'
import LocationTurnedOff from '../components/LocationTurnedOff'
import {gql} from 'react-apollo'
import apolloClient from '../apolloClient'
import moment from 'moment';

const manImage = require('../images/man.png')
const siteImage = require('../images/site.png')

class Home extends React.Component {
  static navigationOptions = {
    tabBarIcon: () => (<Ionicons name="md-home" size={30} color="white" />),
  }

  constructor(props) {
    super(props)
    this.state = {
      markers: [],
      status: props.screenProps.user.status,
      loading: false
    }
    this.mapRef = null;
    console.log("--------->>>>>>", props)
  }

  componentDidMount() {
    const { findLocation } = this.props;

    console.log("Screen props\n", this.props.screenProps)
    const {user} = this.props.screenProps
    if(user.userOnSites[0]) {
      // setDeviceDetails(user)
      findLocation(user.userOnSites[0].site, user)
    }
  }

  checkIn = (oldStatus, site, user) => {
    const status = (oldStatus === 'IN') ? 'OUT' : 'IN'
    console.log(status, site, user)
    const UpdateUserQuery = gql`
      mutation createAttendance(
        $status: RESOURCE_STATUS!,
        $type: ATTENDANCE_TYPE!,
        $managerId: ID,
        $siteId: ID!, $userId: ID!, $createdDate: DateTime!) {
        createAttendance(type: $type, siteId: $siteId, userId: $userId, createdDate: $createdDate, managerId: $managerId) {
          id
        }
        updateUser(status: $status, id: $userId) {
          id
        }
      }

    `
    const createdDate = moment().startOf('day').toISOString()
    this.setState({loading: true})
    const managerId = user.manager ? user.manager.id : null
    const variables = {
      type: status,
      siteId: site.id,
      userId: user.id,
      managerId,
      status,
      createdDate
    }
    apolloClient.mutate({mutation: UpdateUserQuery, variables })
      .then((response) => {
        console.log(response)
        this.setState({status, loading: false});
      })
      .catch(e => {
        console.log("Error ---> ", e)
        this.setState({loading: false});
      })
  }

  welcomeMessage = (siteLng, diff, user) => {
    if(!siteLng) return "You have not been assigned a site yet."
    if(siteLng && diff > 0.05) return `You are ${diff.toFixed(4)} km away`
    return `Welcome ${user.name}`
  }

  render() {
    const {location} = this.props;
    const {lat, lng, diff, gpsEnabled} = location
    const user = this.props.screenProps.user;
    const site = user.userOnSites[0] ? user.userOnSites[0].site : null
    const {status, loading} = this.state
    if(!gpsEnabled) return(<LocationTurnedOff />)
    if(!lat) return(<Spinner visible />)

    let markers = [
      {id: '1', title: 'Current Location', latlng: {latitude: lat, longitude: lng}, image: manImage},
    ]
    if (site) {
      markers.push({id: '2', title: site.name, latlng: {latitude: site.lat, longitude: site.lng}, image: siteImage})
    }
    const btnOptions = {
      'IN': {color: "lightcoral", text: "CHECK-OUT", action: 'check-out'},
      'OUT': {color: "seagreen", text: "CHECK-IN", action: 'check-in'},
    }[status]

    const outOfSite = (!site || diff > 0.05)

    return (
      <View style={{flex: 1}}>
        <Spinner visible={loading} />
        <Text style={{fontSize: 16, height: '6%', alignSelf: 'center'}}>
          {this.welcomeMessage(site, diff, user) }
        </Text>
        <Gmaps markers={markers} initLat={lat} initLng={lng} />

        <TouchableOpacity
          onPress={() => this.checkIn(status, site, user)}
          style={{
            alignItems: 'center', marginBottom: 2, backgroundColor: btnOptions.color, justifyContent: 'center', height: 50
          }}
          disabled={outOfSite}
          activeOpacity={outOfSite ? 1 : 0.7}
          >
          <Text style={{color: "white", fontSize: 20}}>{btnOptions.text}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

export default connect(
  (state) => ({
    location: state.location
  }),
  { findLocation }
)(Home);
