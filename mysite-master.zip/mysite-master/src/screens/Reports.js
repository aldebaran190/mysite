import React from 'react';
import { TextInput, Text, View, Button, TouchableOpacity, Alert } from 'react-native';
import styles from '../styles';
import { connect } from 'react-redux'
import { Ionicons } from '@expo/vector-icons';
import firebase from '../firebase'
import Spinner from 'react-native-loading-spinner-overlay';
import DatePicker from 'react-native-datepicker';

class Reports extends React.Component {
  static navigationOptions = {
    title: 'New Report',
    tabBarIcon: () => (<Ionicons name="md-settings" size={30} color="white" />),
  }

  state = {
    loading: false,
  }

  changeReport() {
    const user = this.props.user
    const ref = `${user.company}/reports`
    const setState = this.setState.bind(this)
    const date = this.state.date || new Date().toISOString().split('T')[0]
    setState({loading: true})
    const report = {
      message: this.state.message,
      date,
      createdAt: new Date().getTime(),
      userId: user.uid,
      manager: user.manager || null,
    }
    firebase.database().ref(ref).push(report).then(() => {
      setState({loading: false, message: null, date: new Date().toISOString().split('T')[0]})
      Alert.alert(
        'SUCCESS',
        'Your report has been updated successfully',
        [
          {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
        ]
      )
    }, (e) => {
      setState({loading: false})
      Alert.alert(
        'ERROR',
        e.message,
        [
          {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
        ]
      )
    });
  }

  render() {
    return (
      <View>
        <Spinner visible={this.state.loading} />
        <TextInput
            style={[styles.input, {width: '88%',
            padding: 10,
            marginLeft: '6%',
            marginRight: '6%',
            marginTop: '2%',
            marginBottom: '2%'}]}
            placeholder="New Report"
            value={this.state.message}
            onChangeText={(e) => this.setState({message: e})}
        />
        <DatePicker
          style={{width: 160}}
          date={this.state.date || new Date()}
          mode="date"
          placeholder="Select date ..."
          format="YYYY-MM-DD"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          onDateChange={(date) => {this.setState({date: date})}}
        />
        <Button
            color="seagreen"
            onPress={() => this.changeReport()}
            title="Add"
        />
      </View>
    );
  }
}

export default connect(
  (state) => ({
    user: state.application.user,
  })
)(Reports);
