import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Image,
  Dimensions,
  TextInput,
  Button,
  TouchableOpacity
} from 'react-native';
import { gql, graphql } from 'react-apollo';
import { setUser } from '../reducers/application'
import { connect } from 'react-redux'
import oldStyles from '../styles';
const { width, height } = Dimensions.get("window");
import { AsyncStorage } from 'react-native';
import { Permissions, Notifications } from 'expo';
const background = require("../images/login1_bg.png");
const mark = require("../images/login1_mark.png");
const lockIcon = require("../images/login1_lock.png");
const personIcon = require("../images/login1_person.png");

class LoginScreen extends Component {
  static navigationOptions = {
    header: null
  }

  state = {
    phone: '',
    password: '',
    errors: null,
    loading: false
  }

  async componentDidMount() {
    try {
      const { getAsync, REMOTE_NOTIFICATIONS, askAsync } = Permissions;
      const { existingStatus } = await getAsync(REMOTE_NOTIFICATIONS);
      let finalStatus = existingStatus;
      if (existingStatus !== 'granted') {
        const { status } = await getAsync(REMOTE_NOTIFICATIONS);
        finalStatus = status;
      }

      if (finalStatus === 'granted') {
        const token = await Notifications.getExponentPushTokenAsync();
        this.setState({token})
      }
    } catch (e) {
      console.log(e.message);
    }
  }

  login = (token, phone, password) => {
    this.setState({loading: true});
    const setUser = this.props.setUser
    this.props.mutate({
      variables: {phone: phone.trim(), password: password.trim(), token}
    }).then(resp => {
      const id = resp.data.authenticateUser.id
      console.log("USER ID ---> ", id)
      AsyncStorage.setItem('userId', id)
      setUser(id)
      this.setState({loading: false});
    }).catch(() => {
      this.setState({loading: false, errors: 'Invalid credentials'});
    })
  }

  showErrors(errors) {
    return(
      <View style={oldStyles.errorBox}>
        <Text style={oldStyles.errorText}>
          {errors}
        </Text>
      </View>
    )
  }

  render() {
    const { token, phone, password, errors, loading } = this.state;
    return (
      <View style={styles.container}>
        <Image source={background} style={styles.background} resizeMode="cover">
          <View style={styles.markWrap}>
            <Image source={mark} style={styles.mark} resizeMode="contain" />
          </View>
          <View style={styles.wrapper}>
            <View style={styles.inputWrap}>
              <View style={styles.iconWrap}>
                <Image source={personIcon} style={styles.icon} resizeMode="contain" />
              </View>
              <TextInput
                placeholder="Phone"
                placeholderTextColor="#FFF"
                onChangeText={(e) => this.setState({phone: e})}
                style={styles.input}
                />
            </View>
            <View style={styles.inputWrap}>
              <View style={styles.iconWrap}>
                <Image source={lockIcon} style={styles.icon} resizeMode="contain" />
              </View>
              <TextInput
                placeholderTextColor="#FFF"
                placeholder="Password"
                onChangeText={(e) => this.setState({password: e})}
                style={styles.input}
                secureTextEntry
                />
            </View>
            {errors ? this.showErrors(errors) : null}
            <TouchableOpacity onPress={() => this.props.navigation.navigate('ForgotPassword')} activeOpacity={.5}>
              <View>
                <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={.5}
              disabled={loading}
              onPress={() => this.login(token, phone, password)}
              >
              <View style={styles.button}>
                <Text style={styles.buttonText}>Sign In</Text>
              </View>
            </TouchableOpacity>
          </View>
          <View style={styles.container}>
            <View style={styles.signupWrap}>
              <Text style={styles.accountText}>{"\n"}</Text>
              <TouchableOpacity activeOpacity={.5}>
                <View>
                  <Text style={styles.signupLinkText}>{"\n"}</Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </Image>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  markWrap: {
    flex: 1,
    paddingVertical: 30,
  },
  mark: {
    width: null,
    height: null,
    flex: 1,
  },
  background: {
    width,
    height,
  },
  wrapper: {
    paddingVertical: 30,
  },
  inputWrap: {
    flexDirection: "row",
    marginVertical: 10,
    height: 40,
    borderBottomWidth: 1,
    borderBottomColor: "#CCC"
  },
  iconWrap: {
    paddingHorizontal: 7,
    alignItems: "center",
    justifyContent: "center",
  },
  icon: {
    height: 20,
    width: 20,
  },
  input: {
    flex: 1,
    paddingHorizontal: 10,
  },
  button: {
    backgroundColor: "#FF3366",
    paddingVertical: 20,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 30,
  },
  buttonText: {
    color: "#FFF",
    fontSize: 18,
  },
  forgotPasswordText: {
    color: "#D8D8D8",
    backgroundColor: "transparent",
    textAlign: "right",
    paddingRight: 15,
  },
  signupWrap: {
    backgroundColor: "transparent",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  accountText: {
    color: "#D8D8D8"
  },
  signupLinkText: {
    color: "#FFF",
    marginLeft: 5,
  }
});

const NewLogin = connect(
  null,
  {setUser}
)(LoginScreen);


const LoginQuery = gql`
      mutation authenticateUser($phone: String!, $password: String!, $token: String!) {
        authenticateUser(phone: $phone, password: $password, token: $token) {
          id
        }
      }
`
export default graphql(LoginQuery)(NewLogin)
