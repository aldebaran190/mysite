import React from 'react';
import { TextInput, Text, View, Button, TouchableOpacity, Alert } from 'react-native';
import styles from '../styles';
import { connect } from 'react-redux'
import { Ionicons } from '@expo/vector-icons';
import firebase from '../firebase'
import Spinner from 'react-native-loading-spinner-overlay';
import {gql, graphql} from 'react-apollo'

class Settings extends React.Component {
  static navigationOptions = {
    header: false,
    tabBarIcon: () => (<Ionicons name="md-settings" size={30} color="white" />),
  }

  state = {
    password: '',
    newPassword: ''
  }

  changePassword = (password, newPassword) => {
    this.setState({loading: true})
    const id = this.props.screenProps.user.id
    const variables = {
      id,
      password,
      newPassword
    }
    this.props.updatePasswordMutation({variables})
      .then((json) => {
        console.log(json)
        console.log("succes...")
        this.setState({loading: false, password: '', newPassword: ''})
        Alert.alert(
          'SUCCESS',
          'Password updated successfully',
          [
            {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
          ]
        )
      })
      .catch(e => {
        this.setState({loading: false})
        console.log("Error -> ", e)
        Alert.alert(
          'ERROR',
          'Invalid password',
          [
            {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
          ]
        )
      })
  }

  render() {
    const {password, newPassword} = this.state

    return (
      <View>
        <Spinner visible={this.state.loading} />
        <Text>{"\n"}</Text>
        <Text style={{fontWeight: 'bold', width: '88%',
                      fontSize: 20,
                      padding: 10,
                      marginLeft: '6%',
                      marginRight: '6%',
                      marginTop: '2%',
              marginBottom: '2%'}}>Change Password</Text>
        <TextInput
          style={[styles.input, {width: '88%',
                                 padding: 10,
                                 marginLeft: '6%',
                                 marginRight: '6%',
                                 marginTop: '2%',
          marginBottom: '2%'}]}
          placeholder="Current Password"
          value={password}
          onChangeText={(e) => this.setState({password: e})}
          />

          <TextInput
            style={[styles.input, {width: '88%',
                                   padding: 10,
                                   marginLeft: '6%',
                                   marginRight: '6%',
                                   marginTop: '2%',
            marginBottom: '2%'}]}
            placeholder="New Password"
            value={newPassword}
            onChangeText={(e) => this.setState({newPassword: e})}
            />

            <Button
              color="seagreen"
              onPress={() => this.changePassword(password, newPassword)}
              title="Confirm"
              />
              <Text>{"\n"}</Text>
              <Text style={{fontWeight: 'bold', width: '88%',fontSize: 20, padding: 10, marginLeft: '6%', marginRight: '6%',
                    marginTop: '2%', marginBottom: '2%'}}>Signout</Text>
              <Text>{"\n"}</Text>
              <TouchableOpacity onPress={() => this.props.navigation.navigate('Reports')} style={{alignItems: 'center', backgroundColor: "seagreen", justifyContent: 'center', height: 35}}>
                <Text style={{color: "white", fontSize: 14, fontWeight: 'bold'}}>REPORTS</Text>
              </TouchableOpacity>
      </View>
    );
  }
}

const updatePassword = gql`
  mutation updatePassword($id: String!, $password: String!, $newPassword: String!) {
    updatePassword(id: $id, password: $password, newPassword: $newPassword) {
      id
    }
  }
`

export default graphql(updatePassword, {name : 'updatePasswordMutation'})(Settings)
