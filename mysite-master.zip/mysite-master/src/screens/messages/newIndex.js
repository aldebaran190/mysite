import React from 'react';
import { Text, ListView, TextInput, View, TouchableHighlight, StyleSheet, TouchableOpacity, KeyboardAvoidingView } from 'react-native';
import { connect } from 'react-redux'
import {gql, graphql} from 'react-apollo'
import { Ionicons, FontAwesome } from '@expo/vector-icons';
import moment from 'moment'
import indexStyles from './indexStyles'
import Spinner from 'react-native-loading-spinner-overlay';

class Index extends React.Component {
  static navigationOptions = {
    header: false,
    tabBarIcon: () => (<Ionicons name="md-text" size={30} color="white" />),
  }

  constructor(props) {
    super(props);
    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {
      messages: [],
      ds,
      loading: false
    }
  }
  async componentDidMount() {
    const id = this.props.screenProps.user.id;

    this.createMessageSubscription = this.props.data.subscribeToMore({
      document: gql`
            subscription listenToNewMessage($id: ID!){
            Message(filter: {
                mutation_in: [CREATED]
                OR: [{node: {from: {id: $id}}}, {node: {to: {id: $id}}}]
            }) {
               mutation
                node {
                    id
                    text
                    createdAt
                    from {
                        id
                        name
                    }
                    to {
                        id
                        name
                    }
                }
            }
        }
    `,
      variables: {id},
      updateQuery: (previousState, {subscriptionData}) => {
        const newMessage = subscriptionData.data.Message.node
        const messages = previousState.allMessages.concat([newMessage])
        return {
          allMessages: messages,
        }
      },
      onError: (err) => console.error(err),
    })
  }

  renderRows(x) {
    return(
      <TouchableOpacity style={indexStyles.container}>
        <View style={indexStyles.titleWrapper}>
          <Text style={indexStyles.receiverName}>{x.to.name}</Text>
          <Text style={indexStyles.createdAt}>{moment(x.createdAt).fromNow()}</Text>
        </View>
        <View>
          <Text style={[indexStyles.message, {textAlign: x.align}]}>{x.text}</Text>
        </View>
      </TouchableOpacity>
    )
  }

  createMessage = () => {
    const user = this.props.screenProps.user

    const newMessage = {
      fromId: user.id,
      toId: user.manager ? user.manager.id : null,
      text: this.state.message
    }
    this.props.createMessageMutation({variables: newMessage})
      .then(() => {
        this.setState({loading: false, message: ''})
      })
      .catch(e => {
        this.setState({loading: false})
        Alert.alert(
          'ERROR',
          e.message,
          [
            {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
          ]
        )
      })
  }

  render() {
    const {ds} = this.state
    const { allMessages, loading} = this.props.data;

    if(loading) return <Spinner visible={true} />
    const dataSource = ds.cloneWithRows(allMessages)
    return(
      <KeyboardAvoidingView
        style={{flex: 1}}
        keyboardVerticalOffset={150}
        behavior="padding"
        >
        <ListView
          dataSource={dataSource}
          renderRow={(data) => this.renderRows(data)}
          enableEmptySections={true}
          />

          <TextInput
            style={indexStyles.messageInput}
            placeholder="Type a message"
            value={this.state.message}
            underlineColorAndroid='transparent'
            onChangeText={(e) => this.setState({message: e})}
            />

            <TouchableOpacity onPress={this.createMessage} style={indexStyles.submitArrow} >
              <FontAwesome name="chevron-circle-right" size={50} color={loading ? "gray" : "seagreen"} />
            </TouchableOpacity>
      </KeyboardAvoidingView>
    )
  }
}

const allMessages = gql`
  query allMessages($id: ID!) {
    allMessages(filter: {
     OR: [{from: {id: $id}}, {to: {id: $id}}]
}) {
      id
      text
      createdAt
      from {
        id
        name
      }
      to {
        id
        name
      }
    }
  }
`

const createMessage = gql`
  mutation createMessage($text: String!, $fromId: ID!, $toId: ID!) {
    createMessage(text: $text, fromId: $fromId, toId: $toId) {
      id
      text
      createdAt
    }
  }
`

export default graphql(createMessage, {name : 'createMessageMutation'})(
  graphql(allMessages, {
    options: (props) => ({
      variables: {id: props.screenProps.user.id}
    })
  })(Index)
)
