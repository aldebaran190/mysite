import React from 'react';
import { TextInput, Text, View, Button, Alert } from 'react-native';
import styles from '../../styles';
import { connect } from 'react-redux'
import { Ionicons } from '@expo/vector-icons';
import firebase from '../../firebase';

class New extends React.Component {
  static navigationOptions = {
    title: 'New Message',
    tabBarIcon: () => (<Ionicons name="md-create" size={30} color="white" />),
  }

  state = {
    message: '',
    loading: false,
    errors: null,
  }

  createMessage = () => {
    const user = this.props.user
    const message = this.state.message
    const setState = this.setState.bind(this)
    setState({loading: true})

    const newMessage = {
      userId: user.uid,
      userName: user.name,
      subjectId: user.uid,
      createdAt: new Date().getTime(),
      message
    }
    firebase.database().ref(user.company + '/messages').push(newMessage)
            .then(() => {
              setState({loading: false, message: ''})
              Alert.alert(
                'SUCCESS',
                'Your message has been sent successfully',
                [
                  {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
                ]
              )
            })
            .catch(e => {
              setState({loading: false, errors: e.message})
            })
  }

  showErrors(errors) {
    return(
      <View style={styles.errorBox}>
        <Text style={styles.errorText}>
          {errors}
        </Text>
      </View>
    )
  }

  render() {
    const loading = this.state.loading
    return (
      <View style={styles.form}>
        <TextInput
            multiline={true}
            numberOfLines={4}
            style={styles.input}
            placeholder="Message"
            value={this.state.message}
            onChangeText={(e) => this.setState({message: e})}
        />
        {this.state.errors ? this.showErrors(this.state.errors) : null}
        <Button
            color="seagreen"
            onPress={this.createMessage}
            disabled={loading}
            title={loading ? "Submitting" : "Submit"}
        />
      </View>
    );
  }
}

export default connect(
  (state) => ({
    user: state.application.user,
  }),
)(New);
