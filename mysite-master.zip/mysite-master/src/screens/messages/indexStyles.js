import { StyleSheet } from 'react-native';

export default indexStyles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
    width: '70%',
    borderBottomWidth: 2,
    padding: 4,
    marginLeft: '6%',
    marginRight: '6%',
    marginTop: '2%',
    marginBottom: '2%',
    borderRadius: 8,
    borderWidth: 0.7,
    borderColor: '#5CC9DD',
    backgroundColor: '#D4D7D7',
    justifyContent: 'center'
  },

  titleWrapper:{
    flex: 1,
    flexDirection:'row',
    justifyContent:'space-between',
    width:280
  },

  receiverName:{
    marginLeft:15,
    fontWeight:'600'
  },

  createdAt:{
    color:'#333',
    fontSize:10,
    marginRight: 50
  },

  message:{
    marginLeft:15
  },

  newMessageBox: {
    flex: 1,
    flexDirection: 'row'
  },

  messageInput: {
    width: '80%',
    padding: 10,
    top: 57,
    marginLeft: 10,
    borderWidth: 0.5,
    borderRadius: 80,
    marginTop: 6,
    borderColor: '#A5978B',
    alignSelf: 'flex-start',
  },

  submitArrow: {
    top: 0,
    padding: 10,
    alignSelf: 'flex-end',
    height: 60

  }

});
