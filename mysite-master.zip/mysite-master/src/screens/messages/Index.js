import React from 'react';
import { GiftedChat } from 'react-native-gifted-chat';
import { Ionicons } from '@expo/vector-icons';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import { Alert, View, Platform } from 'react-native';
import {gql, graphql} from 'react-apollo'

class Index extends React.Component {
  static navigationOptions = {
    header: false,
    tabBarIcon: () => (<Ionicons name="md-text" size={30} color="white" />),
  }

  async componentDidMount() {
    const id = this.props.screenProps.user.id;
    this.createMessageSubscription = this.props.data.subscribeToMore({
      document: gql`
            subscription listenToNewMessage($id: ID!){
            Message(filter: {
                mutation_in: [CREATED]
                OR: [{node: {from: {id: $id}}}, {node: {to: {id: $id}}}]
            }) {
               mutation
               node {
                    _id: id
                    text
                    createdAt
                    user: from {
                        _id: id
                        name
                    }
               }
            }
        }
    `,
      variables: {id},
      updateQuery: (previousState, {subscriptionData}) => {
        const newMessage = subscriptionData.data.Message.node
        const allMessages = previousState.allMessages || []
        return {
          allMessages: GiftedChat.append(allMessages, [newMessage])
        }
      },
      onError: (err) => console.error(err),
    })
  }

  onSend = ([msg]) => {
    const user = this.props.screenProps.user
    const newMessage = {
      fromId: user.id,
      toId: user.manager ? user.manager.id : null,
      text: msg.text
    }
    this.props.createMessageMutation({variables: newMessage})
      .then((json) => {
        console.log(json)
        console.log("succes...")
        this.setState({loading: false, message: ''})
      })
      .catch(e => {
        this.setState({loading: false})
        console.log(e)
        console.log("error...")
        Alert.alert(
          'ERROR',
          e.message,
          [
            {text: 'OK', onPress: () => console.log('OK Pressed'), style: 'cancel'}
          ]
        )
      })
  }

  render() {
    const user = this.props.screenProps.user
    return (
      <View style={ { flex: 1 } }>
        <GiftedChat
          messages={this.props.data.allMessages}
          onSend={(messages) => this.onSend(messages)}
          user={{_id: user.id}}
          />
      </View>
    );
  }
}

const allMessages = gql`
  query allMessages($id: ID!) {
    allMessages(filter: {
     OR: [{from: {id: $id}}, {to: {id: $id}}]
}, orderBy: createdAt_DESC) {
        _id: id
        text
        createdAt
        user: from {
            _id: id
            name
        }
    }
  }
`

const createMessage = gql`
  mutation createMessage($text: String!, $fromId: ID!, $toId: ID!) {
    createMessage(text: $text, fromId: $fromId, toId: $toId) {
      id
      text
      createdAt
    }
  }
`

export default graphql(createMessage, {name : 'createMessageMutation'})(
  graphql(allMessages, {
    options: (props) => ({
      variables: {id: props.screenProps.user.id}
    })
  })(Index)
)
